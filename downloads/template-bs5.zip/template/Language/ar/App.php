<?php


return [
    'new' => ' إضافة مستخدم',
    'add'  => 'إضافة',
    'edit'  => 'تعديل',
    'update' => 'تحديث',
    'delete' => 'حذف',
    'copy' => 'نسخ',
    'save'  => 'حفظ',
    'confirm' =>'تأكيد',
    'cancel'  => 'تراجع',
    'remove-title' => 'هل أنت متأكد من عملية الحذف؟',
    'remove-text' => 'لا يمكنك التراجع بعد التأكيد',
    'insert-success' => 'تم إدراج البيانات بنجاح',
    'insert-error' => 'خطأ في إدراج البيانات!',
    'update-success' => 'تم التحديث بنجاح',
    'update-error' => 'خطأ في عملية التحديث!',
    'delete-success' => 'تم الحذف بنجاح',
    'delete-error' => 'خطأ في عملية الحذف!',
 
];