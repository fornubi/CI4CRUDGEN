<?= $this->extend("layout/master") ?>

<?= $this->section("content") ?>

<!-- code here.. -->

<?= $this->endSection() ?>

<?= $this->section("pageScript") ?>
<!-- write script here.. -->
<?= $this->endSection() ?>