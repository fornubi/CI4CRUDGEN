/*! Bootstrap integration for DataTables' StateRestore
 * ©2016 SpryMedia Ltd - datatables.net/license
 */
declare let define: {
    (stringValue: any, Function: any): any;
    amd: string;
};
